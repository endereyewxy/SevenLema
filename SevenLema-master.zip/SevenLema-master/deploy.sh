#!/bin/sh
scp SevenLema-master.zip root@47.94.149.131:/root/
